<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index'); // Halaman utama

// Register Routes
$routes->group('register', function($routes){
    $routes->get('/', 'RegisterController::index'); // Formulir pendaftaran (GET)
    $routes->post('submit', 'RegisterController::submit'); // Proses pengiriman formulir (POST)
});

// Login Routes
$routes->group('login', function ($routes) {
    $routes->get('/', 'LoginController::index'); // Formulir login (GET)
    $routes->post('/', 'LoginController::login'); // Proses login (POST)
});

$routes->get('lupa-password', 'LoginController::lupaPassword');
$routes->post('proses-lupa-password', 'LoginController::prosesLupaPassword');
$routes->get('reset-password/(:any)', 'LoginController::resetPassword/$1');
$routes->post('proses-reset-password/(:any)', 'LoginController::prosesResetPassword/$1');


// Dashboard Route
$routes->get('/dashboard', 'Dashboard::index'); // Halaman dashboard


$routes->group('logout', function ($routes) {
    $routes->get('/', 'LogoutController::index');
});

$routes->get('tes/tesDepresi', 'TesDepresiController::depression');    // Menampilkan form tes
$routes->post('tes/tesDepresi/submit', 'TesDepresiController::submitDepression'); // Submit jawaban tes

$routes->get('tes/tesAnxienty', 'TestAnxientyController::anxienty');
$routes->post('tes/tesAnxienty/submit', 'TestAnxientyController::submitAnxienty');

$routes->get('profile', 'UserController::index');
$routes->post('/profile/update', 'UserController::update');
$routes->get('/profile/delete/(:any)/(:num)', 'UserController::delete/$1/$2');

$routes->get('/profile_edit/(:num)', 'UserController::edit/$1');
$routes->post('/profile_update/(:num)', 'UserController::update/$1');

$routes->get('/profile_delete/(:segment)/(:num)', 'UserController::delete/$1/$2');
$routes->get('profile_delete_data/(:num)', 'UserController::deleteData/$1');
$routes->get('riwayat/delete/(:segment)/(:num)', 'UserController::delete/$1/$2');

$routes->get('/articles', 'Articles::index');


