<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class TesDepresi extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'user_id'      => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'skor_total'   => ['type' => 'INT', 'null' => false],
            'interpretasi' => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => false],
            'waktu_tes'    => ['type' => 'DATETIME', 'null' => false],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');

        $this->forge->createTable('hasil_tes');
    }

    public function down()
    {
        $this->forge->dropTable('hasil_tes');
    }
}
