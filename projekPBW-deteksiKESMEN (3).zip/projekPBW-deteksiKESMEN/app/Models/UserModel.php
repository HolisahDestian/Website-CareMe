<?php
namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'user_id';
    
    // Tambahkan reset_token dan reset_expired di sini:
    protected $allowedFields    = [
        'nik', 'nama', 'jenis_kelamin', 'tanggal_lahir', 'alamat',
        'email', 'password', 'reset_token', 'reset_expired'
    ];

    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $validationRules = [
        'nik'            => 'required|numeric|is_unique[users.nik]',
        'nama'           => 'required|min_length[3]',
        'jenis_kelamin'  => 'required|in_list[Laki-laki,Perempuan]',
        'tanggal_lahir'  => 'required|valid_date[Y-m-d]',
        'alamat'         => 'required|min_length[5]',
        'email'          => 'required|valid_email|is_unique[users.email]',
        'password'       => 'required|min_length[8]'
    ];

    protected $validationMessages = [
        'nik' => [
            'required'   => 'NIK wajib diisi.',
            'numeric'    => 'NIK harus berupa angka.',
            'is_unique'  => 'NIK sudah terdaftar.'
        ],
        'nama' => [
            'required'     => 'Nama wajib diisi.',
            'min_length'   => 'Nama minimal terdiri dari 3 karakter.'
        ],
        'jenis_kelamin' => [
            'required'     => 'Jenis kelamin wajib dipilih.',
            'in_list'      => 'Jenis kelamin harus Laki-laki atau Perempuan.'
        ],
        'tanggal_lahir' => [
            'required'     => 'Tanggal lahir wajib diisi.',
            'valid_date'   => 'Format tanggal lahir tidak valid (YYYY-MM-DD).'
        ],
        'alamat' => [
            'required'     => 'Alamat wajib diisi.',
            'min_length'   => 'Alamat terlalu pendek.'
        ],
        'email' => [
            'required'     => 'Email wajib diisi.',
            'valid_email'  => 'Format email tidak valid.',
            'is_unique'    => 'Email sudah digunakan.'
        ],
        'password' => [
            'required'     => 'Password wajib diisi.',
            'min_length'   => 'Password minimal 8 karakter.'
        ]
    ];

    protected $skipValidation   = false;

    protected $beforeInsert     = ['hashPassword'];
    protected $beforeUpdate     = ['hashPassword'];

    /**
     * Hash password sebelum insert atau update
     *
     * @param array $data
     * @return array
     */
    protected function hashPassword(array $data): array
    {
        if (isset($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }
        return $data;
    }
}
