<?php
namespace App\Models;

use CodeIgniter\Model;

class TipsModel extends Model
{
    protected $table = 'tips'; // nama tabel di database
    protected $primaryKey = 'id';
    protected $allowedFields = ['judul', 'link', 'jenis'];
}
