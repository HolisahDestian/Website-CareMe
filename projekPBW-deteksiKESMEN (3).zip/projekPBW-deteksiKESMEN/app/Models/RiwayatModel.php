<?php

namespace App\Models;

use CodeIgniter\Model;

class RiwayatModel extends Model
{
    protected $DBGroup = 'default';
    protected $table = ''; // Kosong karena pakai custom query

    public function getRiwayatByUser($userId)
    {
        $db = \Config\Database::connect();

        $sql = "
            SELECT 'Depresi' AS jenis, id, user_id, waktu_tes, skor_total, interpretasi
            FROM hasil_tes
            WHERE user_id = ?
            UNION
            SELECT 'Anxienty' AS jenis, id, user_id, waktu_tes, skor_total, interpretasi
            FROM hasil_tesAnxienty
            WHERE user_id = ?
            ORDER BY waktu_tes DESC
        ";

        $query = $db->query($sql, [$userId, $userId]);

        return $query->getResultArray();
    }

    public function hapusTes($jenis, $id)
    {
        $db = \Config\Database::connect();

        if ($jenis === 'Depresi') {
            return $db->table('hasil_tes')->where('id', $id)->delete();
        } elseif ($jenis === 'Anxienty') {
            return $db->table('hasil_tesAnxienty')->where('id', $id)->delete();
        }

        return false;
    }
}
