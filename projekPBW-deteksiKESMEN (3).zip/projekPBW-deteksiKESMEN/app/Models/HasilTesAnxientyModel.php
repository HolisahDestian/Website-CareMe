<?php

namespace App\Models;

use CodeIgniter\Model;

class HasilTesAnxientyModel extends Model
{
    protected $table = 'hasil_tesAnxienty'; // Sesuaikan dengan nama tabel migration kamu
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'user_id',
        'skor_total',
        'interpretasi',
        'waktu_tes'
    ];

    // Jika kamu ingin otomatis set timestamps, bisa aktifkan ini dan pastikan kolomnya ada
    protected $useTimestamps = false;
    // protected $createdField = 'created_at';
    // protected $updatedField = 'updated_at';
}
