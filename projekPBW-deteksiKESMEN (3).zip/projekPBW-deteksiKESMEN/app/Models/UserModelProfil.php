<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModelProfil extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $allowedFields = [
        'nik', 'nama', 'jenis_kelamin', 'tanggal_lahir', 'alamat',
        'email', 'password', 'foto', 'created_at', 'updated_at'
    ];
    protected $useTimestamps = true;
}