<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Cek Kesehatan Mental (Depresi)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #f3e8ff;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .form-container {
      background: #fff;
      border-radius: 20px;
      padding: 40px;
      max-width: 900px;
      margin: 60px auto;
      box-shadow: 0 5px 30px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .intro-text {
      text-align: center;
      font-size: 1.1rem;
      margin-bottom: 30px;
    }

    .question-box {
      background-color: #f3eaff;
      padding: 20px;
      border-radius: 15px;
      margin-bottom: 25px;
    }

    .question-box strong {
      display: block;
      margin-bottom: 15px;
      font-size: 1.05rem;
    }

    .radio-group {
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 10px;
      text-align: center;
    }

    .radio-option {
      flex: 1 1 22%;
    }

    .radio-option input[type="radio"] {
      margin-bottom: 5px;
    }

    .submit-btn {
      background-color: #6a0dad;
      color: white;
      padding: 12px;
      font-size: 1rem;
      font-weight: bold;
      border: none;
      border-radius: 10px;
      width: 100%;
      margin-top: 30px;
    }

    .submit-btn:hover {
      background-color: #5300a3;
    }

    .alert-error {
      background-color: #f8d7da;
      color: #842029;
      border-radius: 10px;
      padding: 15px;
      margin-bottom: 25px;
      text-align: center;
      font-weight: 600;
    }
  </style>
</head>

<body>

  <div class="form-container">
    <h2>ARE YOU DEPRESSION?</h2>
    <p class="intro-text">Selama <strong><em>2 minggu terakhir</em></strong>, seberapa sering Anda terganggu oleh masalah berikut?</p>

    <!-- Tampilkan pesan error jika ada -->
    <?php if (!empty($error)) : ?>
      <div class="alert-error"><?= esc($error) ?></div>
    <?php endif; ?>

    <form action="<?= base_url('tes/tesDepresi/submit') ?>" method="post">
      <?= csrf_field() ?>

      <?php
      $questions = [
        "Kurang senang atau tertarik dalam kegiatan sehari-hari",
        "Merasa sedih, murung, atau putus asa",
        "Sulit tidur atau tidur berlebihan",
        "Merasa lelah atau kurang energi",
        "Nafsu makan menurun atau meningkat",
        "Merasa bersalah, merasa diri sendiri atau merasa gagal atau mengecewakan diri sendiri atau keluarga",
        "Sulit berkonsentrasi pada hal-hal tertentu",
        "Bergerak atau berbicara sangat lambat atau terlalu gelisah",
        "Berpikiran untuk menyakiti diri sendiri atau merasa lebih baik mati"
      ];

      $options = [
        "0" => "Tidak Pernah",
        "1" => "Beberapa Hari",
        "2" => "Sebagian Besar Hari",
        "3" => "Hampir Setiap Hari"
      ];

      for ($i = 0; $i < count($questions); $i++) {
        $qNumber = $i + 1;
        echo '<div class="question-box">';
        echo "<strong>{$questions[$i]}</strong>";
        echo '<div class="radio-group">';
        foreach ($options as $value => $label) {
          // Jika ada old input, cek untuk checked
          $checked = (isset($old) && isset($old["q$qNumber"]) && $old["q$qNumber"] == $value) ? 'checked' : '';
          echo '<div class="radio-option">';
          echo "<input type='radio' name='q{$qNumber}' value='{$value}' {$checked} required><br>";
          echo "<small>{$label}</small>";
          echo '</div>';
        }
        echo '</div></div>';
      }
      ?>

      <button type="submit" class="submit-btn">Kirim Jawaban</button>
    </form>
  </div>

</body>

</html>
