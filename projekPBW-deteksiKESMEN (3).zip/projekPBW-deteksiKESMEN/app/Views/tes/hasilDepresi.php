<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Hasil Tes Depresi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(135deg, #e0d7f5, #bfa5e2);
      font-family: 'Poppins', sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .result-box {
      background: #fff;
      border-radius: 25px;
      padding: 45px 35px;
      max-width: 650px;
      width: 100%;
      box-shadow: 0 10px 40px rgba(102, 51, 153, 0.2);
      text-align: center;
      animation: fadeInUp 0.8s ease forwards;
      position: relative;
    }

    .result-box::before {
      content: "\f0f6"; /* FontAwesome icon: heartbeat */
      font-family: "Font Awesome 6 Free";
      font-weight: 900;
      font-size: 30px;       /* kecilkan dari 50px jadi 30px */
      color: #8e24aa;
      position: absolute;
      top: -20px;            /* naikkan sedikit */
      left: 50%;
      transform: translateX(-50%);
      background: #fff;
      border-radius: 50%;
      padding: 6px 10px;     /* kecilkan padding */
      box-shadow: 0 4px 15px rgba(142, 36, 170, 0.3);
    }

    .result-box h2 {
      font-weight: 700;
      color: #6a0dad;
      margin-bottom: 35px;
      font-size: 2.2rem;
      letter-spacing: 1px;
    }

    table {
      margin: 0 auto 30px;
      width: 90%;
      max-width: 600px;
      border-collapse: separate;
      border-spacing: 0 12px;
      font-size: 1.1rem;
      color: #444;
    }

    th, td {
      text-align: left;
      padding: 12px 20px;
      background: #f6f0fc;
      border-radius: 12px;
      vertical-align: middle;
      box-shadow: 0 2px 8px rgba(142, 36, 170, 0.1);
    }

    th {
      background: transparent;
      color: #6a0dad;
      font-weight: 600;
      padding-left: 0;
      box-shadow: none;
      font-size: 1.2rem;
      width: 40%;
    }

    td {
      font-weight: 500;
      border-left: 3px solid #8e24aa;
      background: #faf5ff;
      border-radius: 0 12px 12px 0;
    }

    .btn-purple {
      background-color: #8e24aa;
      color: #fff;
      font-weight: 600;
      padding: 12px 40px;
      border-radius: 30px;
      border: none;
      font-size: 1.1rem;
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
      box-shadow: 0 5px 15px rgba(142, 36, 170, 0.4);
      text-decoration: none;
      display: inline-block;
      margin-top: 15px;
    }

    .btn-purple:hover,
    .btn-purple:focus {
      background-color: #6a0dad;
      box-shadow: 0 8px 20px rgba(106, 13, 173, 0.6);
      outline: none;
      text-decoration: none;
      color: #fff;
    }

    @keyframes fadeInUp {
      0% {
        opacity: 0;
        transform: translateY(30px);
      }
      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* Responsive tweaks */
    @media (max-width: 480px) {
      .result-box {
        padding: 35px 25px;
      }

      .result-box h2 {
        font-size: 1.8rem;
      }

      table {
        width: 100%;
      }

      th, td {
        padding: 10px 15px;
      }

      .btn-purple {
        padding: 10px 30px;
        font-size: 1rem;
      }
    }
  </style>
</head>
<body>

  <div class="result-box" role="main" aria-label="Hasil Tes Depresi">
    <h2>Hasil Tes Depresi</h2>

    <table aria-describedby="skor-interpretasi">
      <tbody>
        <tr>
          <th scope="row">Total Skor</th>
          <td><strong><?= esc($score) ?></strong></td>
        </tr>
        <tr>
          <th scope="row">Interpretasi</th>
          <td><strong><?= esc($interpretasi) ?></strong></td>
        </tr>
      </tbody>
    </table>

    <table aria-describedby="deskripsi-solusi">
      <tbody>
        <tr>
          <th scope="row">Deskripsi</th>
          <td><strong><?= nl2br(esc($deskripsi)) ?></strong></td>
        </tr>
        <tr>
          <th scope="row">Solusi</th>
          <td><strong><?= nl2br(esc($solusi)) ?></strong></td>
        </tr>
      </tbody>
    </table>

    <a href="<?= base_url('dashboard') ?>" class="btn-purple" role="button" aria-label="Kembali ke Dashboard">Kembali ke Dashboard</a>
    <a href="<?= base_url('articles') ?>" class="btn-purple" role="button" aria-label="Lihat Tips">Lihat Tips</a>

  </div>

</body>
</html>
