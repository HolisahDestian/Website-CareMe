<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Register - CareMe</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  <style>
    body {
      background-color: #e7d6fb;
      font-family: 'Poppins', sans-serif;
    }

    .register-box {
      background: white;
      border-radius: 20px;
      padding: 40px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      max-width: 500px;
      margin: 80px auto;
    }

    h3 {
      color: #5e2d91;
      font-weight: 700;
      text-align: center;
      margin-bottom: 30px;
    }

    .form-label {
      font-weight: 600;
      color: #5e2d91;
    }

    .form-control {
      border-radius: 12px;
      border: 1px solid #ccc;
    }

    .form-control:focus {
      border-color: #9d7fd6;
      box-shadow: 0 0 6px rgba(125, 86, 183, 0.5);
    }

    .btn-custom {
      background: linear-gradient(135deg, #9b5de5, #7b2cbf);
      color: white;
      font-weight: 600;
      border: none;
      border-radius: 30px;
      padding: 12px;
      box-shadow: 0 5px 15px rgba(123, 44, 191, 0.3);
      transition: all 0.3s ease;
    }

    .btn-custom:hover {
      background: linear-gradient(135deg, #7b2cbf, #5e2d91);
    }

    .form-text {
      font-size: 0.85rem;
      color: #6c757d;
    }

    .alert {
      border-radius: 12px;
      font-size: 0.9rem;
    }

    .text-link {
      color: #7b2cbf;
      text-decoration: none;
      font-weight: 600;
    }

    .text-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="register-box">
    <h3>REGISTER</h3>

    <!-- Flashdata Sukses -->
    <?php if (session()->getFlashdata('success')): ?>
      <div class="alert alert-success">
        <?= session()->getFlashdata('success') ?>
      </div>
    <?php endif; ?>

    <!-- Flashdata Error -->
    <?php if (session()->getFlashdata('error')): ?>
      <div class="alert alert-danger">
        <?= session()->getFlashdata('error') ?>
      </div>
    <?php endif; ?>

    <!-- Validasi Error -->
    <?php if (isset($errors) && is_array($errors) && count($errors) > 0): ?>
      <div class="alert alert-danger">
        <ul class="mb-0">
          <?php foreach ($errors as $error): ?>
            <li><?= esc($error) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form action="<?= base_url('register/submit') ?>" method="post" novalidate>
      <div class="mb-3">
        <label for="nik" class="form-label">NIK</label>
        <input type="text" class="form-control" id="nik" name="nik" required
               value="<?= isset($data['nik']) ? esc($data['nik']) : old('nik') ?>" />
      </div>
      <div class="mb-3">
        <label for="nama" class="form-label">Nama</label>
        <input type="text" class="form-control" id="nama" name="nama" required
               value="<?= isset($data['nama']) ? esc($data['nama']) : old('nama') ?>" />
      </div>
      <div class="mb-3">
        <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
        <select class="form-control" id="jenis_kelamin" name="jenis_kelamin" required>
          <option value="">Pilih Jenis Kelamin</option>
          <option value="Laki-laki" <?= (isset($data['jenis_kelamin']) && $data['jenis_kelamin'] === 'Laki-laki') ? 'selected' : (old('jenis_kelamin') === 'Laki-laki' ? 'selected' : '') ?>>Laki-laki</option>
          <option value="Perempuan" <?= (isset($data['jenis_kelamin']) && $data['jenis_kelamin'] === 'Perempuan') ? 'selected' : (old('jenis_kelamin') === 'Perempuan' ? 'selected' : '') ?>>Perempuan</option>
        </select>
      </div>
      <div class="mb-3">
        <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
        <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" required
               value="<?= isset($data['tanggal_lahir']) ? esc($data['tanggal_lahir']) : old('tanggal_lahir') ?>" />
      </div>
      <div class="mb-3">
        <label for="alamat" class="form-label">Alamat</label>
        <textarea class="form-control" id="alamat" name="alamat" rows="2" required><?= isset($data['alamat']) ? esc($data['alamat']) : old('alamat') ?></textarea>
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" required
               value="<?= isset($data['email']) ? esc($data['email']) : old('email') ?>" />
      </div>
      <div class="mb-4">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" required />
        <div class="form-text">Password harus terdiri dari minimal 8 karakter.</div>
      </div>
      <div class="d-grid">
        <button type="submit" class="btn btn-custom">Register</button>
      </div>
    </form>

    <p class="text-center mt-3">
      Sudah punya akun? <a class="text-link" href="<?= base_url('/login') ?>">Login di sini</a>
    </p>
  </div>

</body>
</html>
