<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
</head>
<body>
    <h3>Reset Password</h3>
    <form method="post" action="<?= base_url('proses-reset-password/' . $token) ?>">
        <label>Password Baru:</label>
        <input type="password" name="password" required />
        <button type="submit">Reset</button>
    </form>
</body>
</html>
