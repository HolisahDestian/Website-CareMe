<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background: linear-gradient(135deg, #e9d8fd, #d6bcfa);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        .login-box {
            background: #fff;
            padding: 2.5rem 2rem;
            border-radius: 1rem;
            box-shadow: 0 8px 20px rgba(150, 123, 182, 0.2);
            width: 100%;
            max-width: 420px;
            transition: transform 0.3s ease;
        }
        .login-box:hover {
            transform: translateY(-4px);
        }
        h3 {
            font-weight: 700;
            color: #5a3e99; /* lebih pekat */
            margin-bottom: 1.5rem;
            letter-spacing: 1.5px;
            text-align: center;
        }
        label {
            font-weight: 600;
            color: #4a3b7b; /* lebih pekat */
        }
        .form-control {
            border-radius: 0.75rem;
            border: 1.5px solid #b7a6f2;
            padding: 0.65rem 1rem;
            font-size: 1rem;
            color: #3f3271; /* teks input lebih pekat */
            transition: border-color 0.3s ease;
            background-color: #faf7ff;
        }
        .form-control::placeholder {
            color: #8f84b7; /* placeholder agak pekat */
        }
        .form-control:focus {
            border-color: #7e6edb;
            box-shadow: 0 0 8px #8c80e0aa;
            outline: none;
            background-color: #fff;
            color: #3a2e65;
        }
        .btn-primary {
            border-radius: 0.75rem;
            padding: 0.75rem 0;
            font-weight: 600;
            background: #7e6edb; /* lebih gelap */
            border: none;
            box-shadow: 0 4px 12px rgba(126, 110, 219, 0.5);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            color: #fff;
        }
        .btn-primary:hover {
            background-color: #6a59bd;
            box-shadow: 0 6px 20px rgba(106, 89, 189, 0.7);
            color: #fff;
        }
        .alert {
            border-radius: 0.75rem;
            font-weight: 600;
        }
        p.mt-3 {
            font-size: 0.9rem;
            color: #5a4d8f; /* teks paragraf lebih pekat */
            text-align: center;
        }
        p.mt-3 a {
            color: #9c8de4;
            font-weight: 600;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        p.mt-3 a:hover {
            color: #7e6edb;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h3>LOGIN</h3>

        <!-- ✅ Flashdata Sukses -->
        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= session()->getFlashdata('success'); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- ❌ Flashdata Error -->
        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= session()->getFlashdata('error'); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <form action="<?= site_url('login') ?>" method="post" novalidate>
            <div class="mb-4">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" value="<?= old('email') ?>" required autofocus placeholder="Masukkan email" />
            </div>
            <div class="mb-4">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" required placeholder="Masukkan password" />
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Login</button>
            </div>
        </form>

        <p class="mt-3">
            Belum punya akun? <a href="<?= base_url('register') ?>">Silahkan daftar</a>
        </p>
</p>
<script>
        setTimeout(() => {
            const alert = document.querySelector('.alert');
            if (alert) {
                const alertInstance = bootstrap.Alert.getOrCreateInstance(alert);
                alertInstance.close();
            }
        }, 3000);
    </script>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>
