<!DOCTYPE html>
<html>
<head>
    <title>Lupa Password</title>
</head>
<body>
    <h3>Lupa Password</h3>
    <?php if (session()->getFlashdata('error')): ?>
        <div><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('success')): ?>
        <div><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>
    <form method="post" action="<?= base_url('proses-lupa-password') ?>">
        <label>Email:</label>
        <input type="email" name="email" required />
        <button type="submit">Kirim Link Reset</button>
    </form>
</body>
</html>
