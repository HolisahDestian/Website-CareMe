<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Edit Profil</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(to right, #f3e8ff, #ede4fb);
      font-family: 'Poppins', sans-serif;
      color: #333;
    }

    .card {
      background-color: #fff;
      border-radius: 20px;
      padding: 35px;
      margin-top: 50px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    h4 {
      font-weight: 600;
      text-align: center;
      color: #6f42c1;
      margin-bottom: 30px;
    }

    .form-label {
      font-weight: 500;
      color: #555;
    }

    .form-control {
      border-radius: 12px;
      border: 1px solid #ccc;
    }

    .btn-primary {
      background-color: #6f42c1;
      border: none;
      padding: 10px 25px;
      font-weight: 500;
      border-radius: 30px;
    }

    .btn-secondary {
      background-color: #adb5bd;
      border: none;
      padding: 10px 25px;
      font-weight: 500;
      border-radius: 30px;
    }

    .btn:hover {
      opacity: 0.9;
    }

    .img-preview {
      width: 100px;
      height: 100px;
      object-fit: cover;
      border-radius: 12px;
      border: 2px solid #ddd;
      box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
    }

    .btn-container {
      display: flex;
      justify-content: space-between;
      margin-top: 30px;
    }
  </style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-7">
      <div class="card shadow">
        <h4>Edit Informasi Pengguna</h4>

        <form action="<?= base_url('profile_update/' . $user['user_id']) ?>" method="post" enctype="multipart/form-data">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label for="nik" class="form-label">NIK</label>
            <input type="text" name="nik" id="nik" class="form-control" value="<?= esc($user['nik']) ?>" required />
          </div>

          <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" name="nama" id="nama" class="form-control" value="<?= esc($user['nama']) ?>" required />
          </div>

          <div class="mb-3">
            <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
            <select name="jenis_kelamin" id="jenis_kelamin" class="form-control" required>
              <option value="Laki-laki" <?= $user['jenis_kelamin'] === 'Laki-laki' ? 'selected' : '' ?>>Laki-laki</option>
              <option value="Perempuan" <?= $user['jenis_kelamin'] === 'Perempuan' ? 'selected' : '' ?>>Perempuan</option>
            </select>
          </div>

          <div class="mb-3">
            <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control" value="<?= esc($user['tanggal_lahir']) ?>" required />
          </div>

          <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <input type="text" name="alamat" id="alamat" class="form-control" value="<?= esc($user['alamat']) ?>" required />
          </div>

          <div class="mb-3">
            <label for="foto" class="form-label">Foto Profil</label>
            <input type="file" name="foto" class="form-control" accept="image/*" />
            <?php if (!empty($user['foto'])): ?>
              <img src="<?= base_url('uploads/' . $user['foto']) ?>" alt="Foto Profil" class="mt-3 img-preview" />
              <div class="form-check mt-2">
                <input class="form-check-input" type="checkbox" name="hapus_foto" id="hapus_foto" value="1">
                <label class="form-check-label text-danger" for="hapus_foto">
                  Hapus foto profil
                </label>
              </div>
            <?php endif; ?>
          </div>

          <div class="btn-container">
            <a href="/profile" class="btn btn-secondary">Batal</a>
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
</body>
</html>
