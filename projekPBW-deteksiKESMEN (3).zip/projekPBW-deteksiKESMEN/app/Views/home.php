<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<style>
  body {
    background: #faf7ff;
    font-family: 'Poppins', sans-serif;
  }

  .hero-wrapper {
    position: relative;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 60px 20px;
    overflow: hidden;
    background: linear-gradient(to bottom, #faf7ff 0%, #f3e8ff 80%);
  }

  .hero-section {
    background: #ffffff;
    padding: 60px 30px;
    border-radius: 32px;
    box-shadow: 0 12px 40px rgba(106, 27, 154, 0.1);
    position: relative;
    text-align: center;
    z-index: 2;
    max-width: 700px;
    width: 100%;
    animation: fadeIn 1s ease;
  }

  .hero-heading {
    font-size: 2.8rem;
    font-weight: 700;
    color: #6a1b9a;
    margin-bottom: 20px;
  }

  .hero-text {
    font-size: 1.15rem;
    color: #4a326f;
    margin-bottom: 30px;
  }

  .btn-outline-primary {
    border-color: #8e24aa;
    color: #8e24aa;
    border-radius: 30px;
    padding: 12px 32px;
    font-weight: 600;
    transition: 0.3s ease;
  }

  .btn-outline-primary:hover {
    background-color: #8e24aa;
    color: #fff;
    box-shadow: 0 5px 15px rgba(142, 36, 170, 0.3);
  }

  .btn-success {
    background-color: #6a1b9a;
    border-color: #6a1b9a;
    color: #fff;
    border-radius: 30px;
    padding: 12px 32px;
    font-weight: 600;
    transition: 0.3s ease;
  }

  .btn-success:hover {
    background-color: #4a126e;
    border-color: #4a126e;
    box-shadow: 0 5px 15px rgba(106, 27, 154, 0.3);
  }

  .wave-container {
    position: absolute;
    bottom: 0;
    width: 100%;
    z-index: 1;
    pointer-events: none;
    line-height: 0;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @media (max-width: 576px) {
    .hero-heading {
      font-size: 2rem;
    }

    .hero-text {
      font-size: 1rem;
    }
  }
</style>

<div class="container hero-wrapper">
  <div class="hero-section">
    <h1 class="hero-heading">🧠 Ayo Cek Kesehatan Mentalmu!</h1>
    <p class="hero-text">
      Di <strong>CareMe</strong>, kami hadir untuk mendukung kesehatan mentalmu.<br>
      Lakukan pengecekan mandiri dan temukan bantuan yang kamu butuhkan.
    </p>

    <div class="d-flex justify-content-center gap-3 flex-wrap mb-4">
      <a href="<?= base_url('login') ?>" class="btn btn-outline-primary btn-lg">Login</a>
      <a href="<?= base_url('register') ?>" class="btn btn-success btn-lg">Register</a>
    </div>
  </div>

  <!-- Wave background (gelombang di atas, garis lurus di bawah) -->
  <div class="wave-container">
    <svg viewBox="0 0 1440 150" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
      <path fill="#e0caff" fill-opacity="1"
        d="M0,150 L0,40 C96,90 192,120 288,115 C384,110 480,80 576,75 C672,70 768,90 864,105 C960,120 1056,130 1152,120 C1248,110 1344,70 1440,40 L1440,150 Z">
      </path>
    </svg>
  </div>
</div>

<?= $this->endSection() ?>
