<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Dashboard - Mental Health</title>
  <link rel="icon" href="/favicon.ico" type="image/x-icon" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    :root {
      --primary:rgb(150, 64, 204);
      --secondary: #a78bfa;
      --bg:linear-gradient(135deg, #f3e5f5, #e1bee7);
      --card: #ffffff;
      --text: #1f1f1f; /* Lebih gelap agar lebih terlihat */
      --shadow: rgba(139, 92, 246, 0.2);
      --highlight: #e9d5ff;
      --accent-dark: #4b0082;
    }

    body {
      background-color: var(--bg);
      font-family: 'Poppins', sans-serif;
      color: var(--text);
      animation: fadeIn 0.8s ease-in-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .navbar-custom {
      background-color: var(--primary);
      box-shadow: 0 4px 12px var(--shadow);
    }
    .navbar-custom .navbar-brand,
    .navbar-custom .nav-link,
    .navbar-custom .btn {
      color: #fff;
    }
    .navbar-custom .btn-danger {
      background-color: #ef4444;
      border: none;
      font-weight: 600;
    }
    .navbar-custom .btn-danger:hover {
      background-color: #dc2626;
    }

    .welcome-card {
      background: var(--card);
      border-radius: 1rem;
      box-shadow: 0 6px 20px var(--shadow);
      padding: 2rem;
      margin-top: 2rem;
      text-align: center;
      color: var(--accent-dark); /* Lebih kuat dari ungu muda */
    }

    .hero-section {
      background: linear-gradient(to right, var(--primary), var(--secondary));
      color: white;
      padding: 4rem 2rem;
      border-radius: 1.5rem;
      text-align: center;
      margin-top: 3rem;
      position: relative;
      overflow: hidden;
    }
    .hero-section h1 {
      font-size: 2.8rem;
      font-weight: 800;
      margin-bottom: 1rem;
      color: #ffffff;
    }
    .hero-section p {
      font-size: 1.2rem;
      color: #f3f3f3;
    }

    .btn-genz {
      background-color: #fff;
      color: var(--primary);
      font-weight: 700;
      padding: 0.7rem 1.5rem;
      border-radius: 2rem;
      border: none;
      box-shadow: 0 4px 12px var(--shadow);
      transition: all 0.3s ease;
    }
    .btn-genz:hover {
      background-color: var(--highlight);
      color: #6b21a8;
    }

    .feature-card {
      background-color: var(--card);
      border-radius: 1.5rem;
      box-shadow: 0 8px 25px var(--shadow);
      padding: 2.5rem 2rem;
      text-align: center;
      transition: transform 0.3s ease;
      color: var(--text);
    }
    .feature-card:hover {
      transform: scale(1.05);
    }

    .feature-icon {
      font-size: 3rem;
      color: var(--primary);
      margin-bottom: 1rem;
    }

    .feature-title {
      font-weight: 700;
      font-size: 1.4rem;
      color: var(--primary);
    }

    footer {
      text-align: center;
      padding: 2rem 1rem;
      color: #4b5563; /* Warna abu gelap agar terlihat jelas */
    }
  </style>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#">CareMe</a>
    <div class="ms-auto">
      <a href="/logout" class="btn btn-danger">Keluar</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="welcome-card">
    <?php $user = session()->get(); ?>
    <h2>Hey, <?= isset($user['nama']) ? esc($user['nama']) : 'Sobat Sehat' ?> 👋</h2>
    <p>Kami siap bantu kamu jadi versi terbaikmu 💜</p>
  </div>

  <section class="hero-section">
    <h1>Kesehatan Mental Itu Penting 🌿</h1>
    <p>Kenali dirimu lebih dalam dan ambil langkah pertama menuju kesejahteraan mental.</p>
    <button class="btn btn-genz mt-3" data-bs-toggle="collapse" data-bs-target="#mentalTests">Mulai Tes Sekarang</button>
    <div class="collapse mt-3" id="mentalTests">
      <a href="/tes/tesAnxienty" class="btn btn-outline-light mt-2">Tes Kecemasan (Anxiety)</a>
      <a href="/tes/tesDepresi" class="btn btn-outline-light mt-2">Tes Depresi</a>
      <p class="mt-3 text-white-50" style="font-size: 0.9rem;">
        *Pertanyaan dalam tes ini diadaptasi dari pedoman World Health Organization (WHO).
      </p>
    </div>
  </section>

  <div class="row g-4 mt-5">
    <div class="col-md-6">
      <div class="feature-card">
        <div class="feature-icon"><i class="bi bi-journal-richtext"></i></div>
        <h5 class="feature-title">Artikel Kesehatan Mental</h5>
        <p>Dapatkan insight dan motivasi dari artikel pilihan terbaik.</p>
        <a href="/articles" class="btn btn-genz">Baca Artikel</a>
      </div>
    </div>
    <div class="col-md-6">
      <div class="feature-card">
        <div class="feature-icon"><i class="bi bi-person-heart"></i></div>
        <h5 class="feature-title">Profil & Riwayat Tes</h5>
        <p>Lihat perjalanan kesehatan mental kamu sejauh ini.</p>
        <a href="/profile" class="btn btn-genz">Lihat Profil</a>
      </div>
    </div>
  </div>

  <footer class="mt-5">
    <small>&copy; <?= date('Y') ?> CareMe. Made with 💜 </small>
  </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
