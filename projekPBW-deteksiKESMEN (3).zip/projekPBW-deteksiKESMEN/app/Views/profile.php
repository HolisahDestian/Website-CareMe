<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Profil Pengguna</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      background: linear-gradient(to right, #e8d1ff, #f6ebff);
      font-family: 'Poppins', sans-serif;
      color: #333;
    }
    .profile-container {
      background-color: white;
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
    }
    .profile-image {
      width: 180px;
      height: 180px;
      border-radius: 15px;
      object-fit: cover;
      border: 5px solid #fff;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    .info-card {
      background-color: #f8f6fc;
      padding: 30px;
      border-radius: 15px;
      box-shadow: inset 0 0 10px rgba(0,0,0,0.03);
    }
    .form-label {
      font-weight: 600;
      color: #444;
    }
    .form-control {
      border-radius: 10px;
      border: 1px solid #c6b5ea;
    }
    .btn {
      border-radius: 30px;
      padding: 10px 20px;
      font-weight: 500;
    }
    .btn-warning {
      background-color: #ffc107;
      color: #fff;
      border: none;
    }
    .btn-danger {
      background-color: #dc3545;
      color: #fff;
      border: none;
    }
    .btn-back {
      text-decoration: none;
      color: #6f42c1;
      font-weight: 500;
    }
    .btn-back:hover {
      text-decoration: underline;
    }
    .card-header {
      background-color: #6f42c1;
      color: white;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
    }
    .table th {
      background-color: #6f42c1;
      color: white;
      text-align: center;
    }
    .table td {
      text-align: center;
      vertical-align: middle;
    }
    .alert {
      border-radius: 12px;
      font-size: 0.95rem;
    }
    .bg-purple {
      background-color: #6f42c1 !important;
    }
    .bg-purple-light {
      background-color: #a073d6 !important;
    }
  </style>
</head>
<body>

<?php
  $hasDepresi = false;
  $hasAnxiety = false;
  foreach ($riwayat as $r) {
    if ($r['jenis'] === 'Depresi') $hasDepresi = true;
    if ($r['jenis'] === 'Anxiety') $hasAnxiety = true;
  }
?>

<div class="container my-5">
  <div class="mb-4">
    <a href="/dashboard" class="btn btn-back" title="Kembali ke Dashboard">❮</a>
  </div>

  <?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <?= session()->getFlashdata('success') ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php elseif (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <?= session()->getFlashdata('error') ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="row profile-container align-items-center">
    <div class="col-md-4 text-center mb-4 mb-md-0">
      <img src="<?= base_url('uploads/' . ($user['foto'] ?? 'default.png')) ?>" alt="Foto Profil" class="profile-image mb-3">
      <h5 class="fw-bold">Hai, <span class="text-primary"><?= esc($user['nama']) ?></span></h5>
    </div>

    <div class="col-md-8">
      <div class="info-card">
        <h5 class="text-center mb-4">Informasi Pengguna</h5>
        <form>
          <div class="row g-3">
            <div class="col-12"><label class="form-label">NIK</label><input type="text" class="form-control" value="<?= esc($user['nik']) ?>" readonly></div>
            <div class="col-12"><label class="form-label">Nama</label><input type="text" class="form-control" value="<?= esc($user['nama']) ?>" readonly></div>
            <div class="col-12"><label class="form-label">Jenis Kelamin</label><input type="text" class="form-control" value="<?= esc($user['jenis_kelamin']) ?>" readonly></div>
            <div class="col-12"><label class="form-label">Tanggal Lahir</label><input type="text" class="form-control" value="<?= esc($user['tanggal_lahir']) ?>" readonly></div>
            <div class="col-12"><label class="form-label">Alamat</label><input type="text" class="form-control" value="<?= esc($user['alamat']) ?>" readonly></div>
          </div>
          <div class="d-flex justify-content-center gap-3 mt-4">
            <a href="<?= base_url('profile_edit/' . $user['user_id']) ?>" class="btn btn-warning">Edit</a>
            <a href="<?= base_url('profile_delete_data/' . $user['user_id']) ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus profil ini? Semua data juga akan hilang.')">Hapus</a>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Riwayat Pemeriksaan -->
  <div class="card mt-5 shadow-sm border-0">
    <div class="card-header text-center">
      <h5>Riwayat Pemeriksaan</h5>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered mb-0">
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Jenis</th>
            <th>Skor</th>
            <th>Interpretasi</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($riwayat)): ?>
            <?php foreach ($riwayat as $r): ?>
              <tr>
                <td><?= esc(date('Y-m-d H:i:s', strtotime($r['waktu_tes']))) ?></td>
                <td><?= esc($r['jenis']) ?></td>
                <td><?= esc($r['skor_total']) ?></td>
                <td><?= esc($r['interpretasi']) ?></td>
                <td>
                  <a href="<?= base_url('riwayat/delete/' . $r['jenis'] . '/' . $r['id']) ?>"
                     class="btn btn-sm btn-outline-danger"
                     onclick="return confirm('Yakin ingin menghapus riwayat ini?')">Hapus</a>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="5">Belum ada riwayat pemeriksaan.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <?php if ($hasDepresi): ?>
    <div class="card mt-5 shadow-sm border-0">
      <div class="card-header text-center bg-purple text-white">
        <h5>Grafik Depresi</h5>
      </div>
      <div class="card-body">
        <canvas id="chartDepresi" height="100"></canvas>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($hasAnxiety): ?>
    <div class="card mt-4 shadow-sm border-0">
      <div class="card-header text-center bg-purple-light text-white">
        <h5>Grafik Anxiety</h5>
      </div>
      <div class="card-body">
        <canvas id="chartAnxiety" height="100"></canvas>
      </div>
    </div>
  <?php endif; ?>
</div>

<script>
<?php if ($hasDepresi || $hasAnxiety): ?>
const labelsDepresi = [];
const dataDepresi = [];

const labelsAnxiety = [];
const dataAnxiety = [];

<?php foreach ($riwayat as $r): ?>
  <?php if ($r['jenis'] === 'Depresi'): ?>
    labelsDepresi.push("<?= date('d/m/Y', strtotime($r['waktu_tes'])) ?>");
    dataDepresi.push(<?= (int)$r['skor_total'] ?>);
  <?php elseif ($r['jenis'] === 'Anxiety'): ?>
    labelsAnxiety.push("<?= date('d/m/Y', strtotime($r['waktu_tes'])) ?>");
    dataAnxiety.push(<?= (int)$r['skor_total'] ?>);
  <?php endif; ?>
<?php endforeach; ?>

<?php if ($hasDepresi): ?>
const ctxDepresi = document.getElementById('chartDepresi')?.getContext('2d');
if (ctxDepresi) {
  new Chart(ctxDepresi, {
    type: 'line',
    data: {
      labels: labelsDepresi,
      datasets: [{
        label: 'Skor Depresi',
        data: dataDepresi,
        borderColor: '#6f42c1',
        backgroundColor: 'rgba(111, 66, 193, 0.15)',
        fill: true,
        tension: 0.3,
        pointRadius: 5,
        pointBackgroundColor: '#6f42c1'
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          title: { display: true, text: 'Skor' }
        },
        x: {
          title: { display: true, text: 'Tanggal' }
        }
      }
    }
  });
}
<?php endif; ?>

<?php if ($hasAnxiety): ?>
const ctxAnxiety = document.getElementById('chartAnxiety')?.getContext('2d');
if (ctxAnxiety) {
  new Chart(ctxAnxiety, {
    type: 'line',
    data: {
      labels: labelsAnxiety,
      datasets: [{
        label: 'Skor Anxiety',
        data: dataAnxiety,
        borderColor: '#a073d6',
        backgroundColor: 'rgba(160, 115, 214, 0.15)',
        fill: true,
        tension: 0.3,
        pointRadius: 5,
        pointBackgroundColor: '#a073d6'
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          title: { display: true, text: 'Skor' }
        },
        x: {
          title: { display: true, text: 'Tanggal' }
        }
      }
    }
  });
}
<?php endif; ?>
<?php endif; ?>
</script>

</body>
</html>