<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Article For You</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f3e5f5, #e1bee7);
      min-height: 100vh;
    }

    .container {
      max-width: 1200px;
    }

    .nav-tabs .nav-link {
      border-radius: 20px;
      margin: 0 5px;
      color: #6a1b9a;
      background-color: #f3e5f5;
      border: none;
    }

    .nav-tabs .nav-link.active {
      background-color: #7b1fa2;
      color: white;
      font-weight: bold;
    }

    .card-custom {
      border: none;
      border-radius: 15px;
      background: #ffffff;
      transition: transform 0.3s, box-shadow 0.3s;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }

    .card-custom:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
    }

    .card-title {
      font-size: 1.1rem;
      font-weight: 500;
      color: #4a148c;
    }

    .btn-read {
      background-color: #8e24aa;
      color: white;
      border-radius: 30px;
    }

    .btn-read:hover {
      background-color: #6a1b9a;
    }

    .tab-pane {
      margin-top: 30px;
    }

    .btn-back:hover {
      background-color: rgb(253, 253, 253);
    }

    footer {
      text-align: center;
      margin-top: 60px;
      padding: 20px 0;
      background-color: #f3e5f5;
      color: #6a1b9a;
      font-size: 0.9rem;
    }
  </style>
</head>
<body>

<div class="container py-5">
  <!-- Back Button -->
  <div class="mb-2">
    <a href="/dashboard" class="btn btn-back" title="Kembali ke Dashboard">❮</a>
  </div>

  <h2 class="text-center fw-bold mb-3 text-dark">🌿 Article For You</h2>

  <!-- Tabs -->
  <ul class="nav nav-tabs justify-content-center flex-wrap" role="tablist">
    <?php $i = 0; foreach ($articles as $key => $data): ?>
      <li class="nav-item m-1" role="presentation">
        <button class="nav-link <?= $i === 0 ? 'active' : '' ?>"
                id="<?= esc($key) ?>-tab"
                data-bs-toggle="tab"
                data-bs-target="#<?= esc($key) ?>"
                type="button"
                role="tab"
                aria-controls="<?= esc($key) ?>"
                aria-selected="<?= $i === 0 ? 'true' : 'false' ?>">
          <?= esc($data['label']) ?>
        </button>
      </li>
    <?php $i++; endforeach; ?>
  </ul>

  <!-- Tab Content -->
  <div class="tab-content">
    <?php $i = 0; foreach ($articles as $key => $data): ?>
      <div class="tab-pane fade <?= $i === 0 ? 'show active' : '' ?>"
           id="<?= esc($key) ?>"
           role="tabpanel"
           aria-labelledby="<?= esc($key) ?>-tab">
        <div class="row mt-4">
          <?php foreach ($data['articles'] as $item): ?>
            <div class="col-sm-6 col-md-4 col-lg-3 mb-4">
              <div class="card card-custom h-100 p-3">
                <div class="card-body d-flex flex-column justify-content-between">
                  <h5 class="card-title"><?= esc($item['judul']) ?></h5>
                  <a href="<?= esc($item['link']) ?>" class="btn btn-read mt-3" target="_blank">🔗 Read More</a>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php $i++; endforeach; ?>
  </div>
</div>

<footer>
  <small>&copy; <?= date('Y') ?> CareMe. Made with 💜</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
