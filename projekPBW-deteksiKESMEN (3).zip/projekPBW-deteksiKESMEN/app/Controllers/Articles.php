<?php
namespace App\Controllers;

use App\Models\TipsModel;
use CodeIgniter\Controller;

class Articles extends Controller
{
    public function index()
    {
        $model = new TipsModel();
        $allTips = $model->findAll();

        $grouped = [];

        // Emotikon berdasarkan jenis
        $emojis = [
            'kesehatan_mental' => '🧠',
            'remajamental'     => '👦',
            'depresi'          => '😔',
            'anxiety'          => '😰'
        ];

        foreach ($allTips as $tip) {
            $key = strtolower(str_replace(' ', '_', $tip['jenis']));
            $labelText = ucwords(str_replace('_', ' ', $key));
            $emoji = $emojis[$key] ?? '📄';

            $grouped[$key]['label'] = $emoji . ' ' . $labelText;
            $grouped[$key]['articles'][] = [
                'judul' => $tip['judul'],
                'link'  => $tip['link']
            ];
        }

        return view('articles', ['articles' => $grouped]);
    }
}
