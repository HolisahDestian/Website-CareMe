<?php

namespace App\Controllers;

use App\Models\UserModel;

class LoginController extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new UserModel();
        helper(['form', 'url']);
    }

    public function index()
    {
        if ($this->isLoggedIn()) {
            return redirect()->to(base_url('dashboard'));
        }
        return view('auth/login', ['title' => 'Login']);
    }

    public function login()
    {
        $email = strtolower(trim($this->request->getPost('email')));
        $password = $this->request->getPost('password');

        if (!$this->validate([
            'email' => 'required|valid_email',
            'password' => 'required|min_length[6]',
        ])) {
            session()->setFlashdata('error', 'Email atau password tidak valid.');
            return redirect()->back()->withInput();
        }

        $user = $this->model->where('email', $email)->first();

        if (!$user) {
            session()->setFlashdata('error', 'Email tidak ditemukan.');
            return redirect()->back()->withInput();
        }

        if (!password_verify($password, $user['password'])) {
            session()->setFlashdata('error', 'Password salah.');
            return redirect()->back()->withInput();
        }

        session()->set([
            'user_id'   => $user['user_id'],
            'nama'      => $user['nama'],
            'email'     => $user['email'],
            'logged_in' => true,
        ]);

        return redirect()->to(base_url('dashboard'));
    }

    private function isLoggedIn(): bool
    {
        return session()->get('logged_in') === true;
    }
}
