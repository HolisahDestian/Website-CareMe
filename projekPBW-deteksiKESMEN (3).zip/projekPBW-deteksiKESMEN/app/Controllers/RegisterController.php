<?php

namespace App\Controllers;

use App\Models\UserModel;

class RegisterController extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new UserModel();
        $this->helpers = ['form', 'url'];
    }

    public function index()
    {
        return view('auth/register');
    }

    public function submit()
    {
        $data = $this->request->getPost(['nik', 'nama', 'jenis_kelamin', 'tanggal_lahir', 'alamat', 'email', 'password']);

        $validationRules = [
            'nik' => 'required|numeric|min_length[16]|max_length[16]',
            'nama' => 'required|min_length[3]',
            'jenis_kelamin' => 'required|in_list[Laki-laki,Perempuan]',
            'tanggal_lahir' => 'required|valid_date[Y-m-d]',
            'alamat' => 'required|min_length[4]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]'
        ];

        if (! $this->validate($validationRules)) {
            return view('auth/register', [
                'errors' => $this->validator->getErrors(),
                'data'   => $data
            ]);
        }

        // HAPUS password_hash DI SINI — biarkan model meng-hash
        $user = [
            'nik'           => $data['nik'],
            'nama'          => $data['nama'],
            'jenis_kelamin' => $data['jenis_kelamin'],
            'tanggal_lahir' => $data['tanggal_lahir'],
            'alamat'        => $data['alamat'],
            'email'         => $data['email'],
            'password'      => $data['password'] // plain password, model akan hash
        ];

        if ($this->model->save($user)) {
            session()->setFlashdata('success', 'Registration successful!');
            return redirect()->to(base_url('login'));
        } else {
            session()->setFlashdata('error', 'There was a problem with the registration.');
            return redirect()->back();
        }
    }
}
