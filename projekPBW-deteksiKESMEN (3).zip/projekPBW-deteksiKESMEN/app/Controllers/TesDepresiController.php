<?php

namespace App\Controllers;

use App\Models\HasilTesModel;
use CodeIgniter\I18n\Time;
use App\Controllers\BaseController;

class TesDepresiController extends BaseController
{
    public function depression()
    {
        $data = [];

        // Kirim pesan error dan input sebelumnya ke view
        if (session()->getFlashdata('error')) {
            $data['error'] = session()->getFlashdata('error');
        }

        $data['old'] = session()->getFlashdata('old_input');

        return view('tes/tesDepresi', $data);
    }

    public function submitDepression()
    {
        $session = session();

        // ✅ Ambil user_id dari session login
        $user_id = $session->get('user_id');
        $request = $this->request;
        $model = new HasilTesModel();

        $totalSkor = 0;

        // Validasi dan hitung skor total dari 9 pertanyaan
        for ($i = 1; $i <= 9; $i++) {
            $nilai = $request->getPost("q$i");
            if ($nilai === null || !is_numeric($nilai) || $nilai < 0 || $nilai > 3) {
                $session->setFlashdata('error', 'Jawaban tidak valid pada pertanyaan ' . $i);
                $session->setFlashdata('old_input', $request->getPost());
                return redirect()->back()->withInput();
            }
            $totalSkor += (int) $nilai;
        }

        // Interpretasi skor
        if ($totalSkor <= 4) {
            $interpretasi = "Tidak Ada atau Minimal Depresi";
            $deskripsi = "Tidak ada gejala atau sangat ringan";
            $solusi = "Jaga pola hidup sehat dan tetap aktif";
        } elseif ($totalSkor <= 9) {
            $interpretasi = "Depresi Ringan";
            $deskripsi = "Gejala ringan, tidak mengganggu aktivitas";
            $solusi = "Lakukan relaksasi dan kegiatan positif";
        } elseif ($totalSkor <= 14) {
            $interpretasi = "Depresi Sedang";
            $deskripsi = "Mulai terasa dan memengaruhi aktivitas";
            $solusi = "Konsultasi ringan dengan psikolog";
        } elseif ($totalSkor <= 19) {
            $interpretasi = "Depresi Lumayan Berat";
            $deskripsi = "Gejala mengganggu kehidupan sehari-hari";
            $solusi = "Lakukan terapi rutin atau konseling";
        } else {
            $interpretasi = "Depresi Berat";
            $deskripsi = "Gejala parah dan mengganggu fungsi hidup";
            $solusi = "Segera temui psikolog atau psikiater";
        }

        // Simpan hasil
        $model->insert([
            'user_id'      => $user_id,
            'skor_total'   => $totalSkor,
            'interpretasi' => $interpretasi,
            'waktu_tes'    => Time::now()->toDateTimeString(),
        ]);

        // Tampilkan hasil ke view
        return view('tes/hasilDepresi', [
            'score' => $totalSkor,
            'interpretasi' => $interpretasi,
            'deskripsi' => $deskripsi,
            'solusi' => $solusi
        ]);
    }
}
