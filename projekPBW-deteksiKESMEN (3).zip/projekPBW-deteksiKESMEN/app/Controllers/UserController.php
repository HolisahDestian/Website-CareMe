<?php

namespace App\Controllers;

use App\Models\UserModelProfil;
use App\Models\HasilTesModel;
use App\Models\HasilTesAnxientyModel;

class UserController extends BaseController
{
    public function index()
    {
        $session = session();
        $userId = $session->get('user_id');

        $userModel = new UserModelProfil();
        $hasilTesModel = new HasilTesModel();
        $hasilTesAnxientyModel = new HasilTesAnxientyModel();

        $data['user'] = $userModel->find($userId);

        // Ambil riwayat depresi
        $riwayatDepresi = $hasilTesModel->where('user_id', $userId)->findAll();
        foreach ($riwayatDepresi as &$item) {
            $item['jenis'] = 'Depresi';
        }

        // Ambil riwayat anxiety
        $riwayatAnxiety = $hasilTesAnxientyModel->where('user_id', $userId)->findAll();
        foreach ($riwayatAnxiety as &$item) {
            $item['jenis'] = 'Anxiety';
        }

        // Gabung dan urutkan berdasarkan waktu
        $riwayat = array_merge($riwayatDepresi, $riwayatAnxiety);
        usort($riwayat, fn($a, $b) => strtotime($b['waktu_tes']) - strtotime($a['waktu_tes']));
        $data['riwayat'] = $riwayat;

        return view('profile', $data);
    }

    public function edit($id)
    {
        helper('form');
        $model = new UserModelProfil();
        $data['user'] = $model->find($id);

        if (!$data['user']) {
            return redirect()->to('/profile')->with('error', 'User tidak ditemukan.');
        }

        return view('profile_edit', $data);
    }

    public function update($id)
    {
        helper(['form']);
        $model = new UserModelProfil();
        $user = $model->find($id);

        if (!$user) {
            return redirect()->to('/profile')->with('error', 'User tidak ditemukan.');
        }

        $data = [
            'nama'           => $this->request->getPost('nama'),
            'nik'            => $this->request->getPost('nik'),
            'jenis_kelamin'  => $this->request->getPost('jenis_kelamin'),
            'tanggal_lahir'  => $this->request->getPost('tanggal_lahir'),
            'alamat'         => $this->request->getPost('alamat'),
        ];

        $hapusFoto = $this->request->getPost('hapus_foto');
        $foto = $this->request->getFile('foto');

        // Jika centang hapus foto
        if ($hapusFoto) {
            if (!empty($user['foto']) && $user['foto'] !== 'default.png') {
                $fotoPath = WRITEPATH . '../public/uploads/' . $user['foto'];
                if (file_exists($fotoPath)) {
                    unlink($fotoPath);
                }
            }
            $data['foto'] = null;
        }

        // Jika upload foto baru
        if ($foto && $foto->isValid() && !$foto->hasMoved()) {
            $newName = $foto->getRandomName();
            $foto->move(WRITEPATH . '../public/uploads', $newName);

            // Hapus foto lama jika ada
            if (!empty($user['foto']) && $user['foto'] !== 'default.png') {
                $oldPath = WRITEPATH . '../public/uploads/' . $user['foto'];
                if (file_exists($oldPath)) {
                    unlink($oldPath);
                }
            }

            $data['foto'] = $newName;
        }

        $model->update($id, $data);

        return redirect()->to('/profile')->with('success', 'Profil berhasil diperbarui.');
    }

    public function delete($jenis, $id)
    {
        if ($jenis === 'Depresi') {
            $model = new HasilTesModel();
        } elseif ($jenis === 'Anxiety') {
            $model = new HasilTesAnxientyModel();
        } else {
            return redirect()->to('/profile')->with('error', 'Jenis tes tidak valid.');
        }

        $data = $model->find($id);
        if ($data) {
            $model->delete($id);
            return redirect()->to('/profile')->with('success', 'Riwayat berhasil dihapus.');
        } else {
            return redirect()->to('/profile')->with('error', 'Data tidak ditemukan.');
        }
    }

    public function deleteData($id)
    {
        $model = new UserModelProfil();
        $user = $model->find($id);

        if (!$user) {
            return redirect()->to('/')->with('error', 'User tidak ditemukan.');
        }

        // Hapus foto jika bukan default
        if (!empty($user['foto']) && $user['foto'] !== 'default.png') {
            $fotoPath = WRITEPATH . '../public/uploads/' . $user['foto'];
            if (file_exists($fotoPath)) {
                unlink($fotoPath);
            }
        }

        $model->delete($id);
        return redirect()->to('/')->with('success', 'Profil telah dihapus.');
    }

    // Opsional: API menampilkan nama file foto (misalnya untuk frontend React/Vue)
    public function show_foto($id)
    {
        $userModel = new UserModelProfil();
        $user = $userModel->find($id);

        if (!$user || empty($user['foto'])) {
            return $this->response->setStatusCode(404);
        }

        return $this->response->setBody($user['foto']);
    }
}
